#ifndef TOWER1_H
#define TOWER1_H
#include <QPoint>
#include <QSize>
#include <QPixmap>
#include <QObject>
#include "tower.h"
class QPainter;
class Enemy;
class MainWindow;
class QTimer;


class Tower1: public Tower
{
    Q_OBJECT
public:
    Tower1(QPoint pos, MainWindow *game, const QPixmap &sprite = QPixmap(":/image/tower1.jpg"));
    ~Tower1();
    void upgrade();//塔升级函数

private://以下成员是随塔类型不同应该区别的属性
    int				m_attackRange;	// 代表塔可以攻击到敌人的距离
    int				m_damage;		// 代表攻击敌人时造成的伤害
    int				m_fireRate;		// 代表再次攻击敌人的时间间隔
    int             m_towertype;    // 塔的类型，基本类型tower为0，tower1为1，tower2为2
};

#endif // TOWER1_H
