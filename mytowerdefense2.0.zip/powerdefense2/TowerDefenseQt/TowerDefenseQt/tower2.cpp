#include "tower.h"
#include "tower2.h"
#include "enemy.h"
#include "bullet.h"
#include "mainwindow.h"
#include "utility.h"
#include <QPainter>
#include <QColor>
#include <QTimer>
#include <QVector2D>
#include <QtMath>

Tower2::Tower2(QPoint pos, MainWindow *game, const QPixmap &sprite/* = QPixmap(":/image/tower.png"*/)
    : Tower(pos, game, sprite)
    , m_attackRange(70)
    , m_damage(10)
    , m_fireRate(1000)
    , m_towertype(2)
{
/*    setfireRate(1000);
    setattackRange(70);
    setdamage(10);*/
    //将开火频率与发射武器槽函数绑定
}

Tower2::~Tower2()
{
    delete m_fireRateTimer;
    m_fireRateTimer = NULL;
}

void Tower2::upgrade(){
    setattackRange(100);
    setdamage(20);
    setfireRate(500);
}
