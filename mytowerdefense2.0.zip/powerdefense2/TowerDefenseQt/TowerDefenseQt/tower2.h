#ifndef TOWER2_H
#define TOWER2_H
#include <QPoint>
#include <QSize>
#include <QPixmap>
#include <QObject>
#include "tower.h"
class QPainter;
class Enemy;
class MainWindow;
class QTimer;


class Tower2: public Tower//这个塔是用来测试选塔的，与tower1功能完全相同，就是买塔花的钱不一样，不用看
{
    //Q_OBJECT
public:
    Tower2(QPoint pos, MainWindow *game, const QPixmap &sprite = QPixmap(":/image/tower2.jpg"));
    ~Tower2();
    void upgrade();

private:
    int				m_attackRange;	// 代表塔可以攻击到敌人的距离
    int				m_damage;		// 代表攻击敌人时造成的伤害
    int				m_fireRate;		// 代表再次攻击敌人的时间间隔
    int             m_towertype;
};

#endif // TOWER1_H
