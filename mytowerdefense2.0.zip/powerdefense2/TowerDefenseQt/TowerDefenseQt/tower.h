#ifndef TOWER_H
#define TOWER_H

#include <QPoint>//重载了运算符和输入输出
#include <QSize>//defines the size of a two-dimensional object using integer point precision以整数精度定义二维对象
#include <QPixmap>//an off-screen image representation that can be used as a paint device是一个离屏图像表示，绘图设备
#include <QObject>

class QPainter;
class Enemy;
class MainWindow;
class QTimer;

class Tower : public QObject
{
    Q_OBJECT//只有加入了Q_OBJECT，才能使用QT中的signal和slot机制，而且Q_OBJECT要放在类的最前面
public:
 //   static const QSize ms_fixedSize;
	Tower(QPoint pos, MainWindow *game, const QPixmap &sprite = QPixmap(":/image/tower.png"));
	~Tower();

	void draw(QPainter *painter) const;
	void checkEnemyInRange();
	void targetKilled();
	void attackEnemy();
	void chooseEnemyForAttack(Enemy *enemy);
	void removeBullet();
	void damageEnemy();
	void lostSightOfEnemy();
    void setfireRate(int newrate);//用于更改开火频率，下面的set函数都是为了更改属性
    void setattackRange(int newrange);//
    void setdamage(int newdamage);//

    int gettowertype();//由于多种塔，每个塔都有自己的类型，于是增加一属性即towertype
    QPoint getpos();//得到塔的中心位置
private slots:
	void shootWeapon();

private:
	bool			m_attacking;
	int				m_attackRange;	// 代表塔可以攻击到敌人的距离
	int				m_damage;		// 代表攻击敌人时造成的伤害
	int				m_fireRate;		// 代表再次攻击敌人的时间间隔
    int             m_towertype;    // 新增属性，塔类型
    qreal			m_rotationSprite;//qreal double旋转图像

	Enemy *			m_chooseEnemy;
	MainWindow *	m_game;

	const QPoint	m_pos;
	const QPixmap	m_sprite;

    static const QSize ms_fixedSize;
protected:
    QTimer *		m_fireRateTimer;
};

#endif // TOWER_H
