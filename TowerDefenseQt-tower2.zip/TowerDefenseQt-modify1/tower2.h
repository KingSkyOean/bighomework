#ifndef TOWER2_H
#define TOWER2_H
#include <QPoint>
#include <QSize>
#include <QPixmap>
#include <QObject>
#include <tower.h>
class QPainter;
class Enemy;
class MainWindow;
class QTimer;
class Tower;

class Tower2: public Tower
{
    Q_OBJECT
public:
    Tower2(QPoint pos, MainWindow *game, const QPixmap &sprite = QPixmap(":/image/tower2.jpg"));
    ~Tower2();
    void chooseEnemyForAttack(Enemy *enemy);//
    void lostSightOfEnemy();

private slots:
    void shootWeapon();

};

#endif // TOWER2_H
