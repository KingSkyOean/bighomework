#include "tower.h"
#include "enemy.h"
#include "bullet.h"
#include "mainwindow.h"
#include "utility.h"
#include <QPainter>
#include <QColor>
#include <QTimer>
#include <QVector2D>
#include <QtMath>
#include <QObject>
#include "tower1.h"

//只更改了图片，也可以整体将QPixmap改为应用QGraphicItem
Tower1::Tower1(QPoint pos, MainWindow *game, const QPixmap &sprite /*= QPixmap(":/image/tower1.png")*/)
    : Tower(pos, game, sprite)
{
    m_attackRange=70;
    m_damage=10;
    m_fireRate=1000;
}

//还需要增加回收金币的操作//在mainwindow中？
//这里是否应当删除图片删除bullet
Tower1::~Tower1(){
    delete m_fireRateTimer;
    m_fireRateTimer = NULL;
}
void Tower1::chooseEnemyForAttack(Enemy *enemy)
{
    m_chooseEnemy = enemy;
    attackEnemy();
    m_chooseEnemy->getAttacked(this);
}
//此处不同的tower的不同等级声明不同的bullet
//同时在mainwindow中增添bullet11 12 21 22的QList
/*void Tower1::shootWeapon(){
    Bullet *bullet = new Bullet(m_pos, m_chooseEnemy->pos(), m_damage, m_chooseEnemy, m_game);
    bullet->bulletmove();
    m_game->addBullet(bullet);
}*/
void Tower1::lostSightOfEnemy()
{
    m_chooseEnemy->gotLostSight(this);
    if (m_chooseEnemy)
        m_chooseEnemy = NULL;

    m_fireRateTimer->stop();
    m_rotationSprite = 0.0;
}
