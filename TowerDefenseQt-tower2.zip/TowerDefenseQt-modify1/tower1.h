#ifndef TOWER1_H
#define TOWER1_H
#include <QPoint>
#include <QSize>
#include <QPixmap>
#include <QObject>
#include <tower.h>////?????
class QPainter;
class Enemy;
class MainWindow;
class QTimer;
class Tower;
//区别在于塔的图片，攻击效力（即子弹的攻击力大小以及特效等）
//升级塔的操作(对单击鼠标的重载）:选定某升级塔，可选位置只有对应的低级塔->替换(一个析构一个创建）//不写在此处
//Tower1(QGraphicsItem * parent=0, double attack_radius);

class Tower1: virtual public Tower
{
    Q_OBJECT
public:
    Tower1(QPoint pos, MainWindow *game, const QPixmap &sprite = QPixmap(":/image/tower.png"));
    ~Tower1();
    void chooseEnemyForAttack(Enemy *enemy);//
    void lostSightOfEnemy();


//private slots:
  //  void shootWeapon();

};

#endif // TOWER1_H
