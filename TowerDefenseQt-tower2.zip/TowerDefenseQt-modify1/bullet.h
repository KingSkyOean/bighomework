#ifndef BULLET_H
#define BULLET_H

#include <QPoint>
#include <QSize>
#include <QPixmap>
#include <QObject>

class QPainter;
class Enemy;
class MainWindow;

class Bullet : QObject
{
	Q_OBJECT
	Q_PROPERTY(QPoint m_currentPos READ currentPos WRITE setCurrentPos)

public:
	Bullet(QPoint startPos, QPoint targetPoint, int damage, Enemy *target,
		   MainWindow *game, const QPixmap &sprite = QPixmap(":/image/bullet.png"));
	void draw(QPainter *painter) const;
    void bulletmove();//与TOWER1的子弹对应//改个名字哈别搞混了
    //void move2();//与TOWER2的子弹对应
	void setCurrentPos(QPoint pos);
	QPoint currentPos() const;

private slots:
    void hitTarget();//TOWER1
   // void slowDownEnemy();//新增信号函数//Tower2


private:
	const QPoint	m_startPos;
	const QPoint	m_targetPos;
	const QPixmap	m_sprite;
	QPoint			m_currentPos;
    Enemy *			m_target;//只是指针不代表成员是吗
	MainWindow *	m_game;
	int				m_damage;

    static const QSize ms_fixedSize;///
};

#endif // BULLET_H
