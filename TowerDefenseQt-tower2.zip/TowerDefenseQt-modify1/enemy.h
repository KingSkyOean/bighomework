#ifndef ENEMY_H
#define ENEMY_H

#include <QObject>
#include <QPoint>
#include <QSize>
#include <QPixmap>
#include<tower.h>
#include<tower1.h>
#include<tower2.h>
class WayPoint;
class QPainter;
class MainWindow;
class Tower;

class Enemy : public QObject
{
	Q_OBJECT
public:
	Enemy(WayPoint *startWayPoint, MainWindow *game, const QPixmap &sprite = QPixmap(":/image/enemy.png"));
	~Enemy();

	void draw(QPainter *painter) const;
	void move();
    void getDamage(int damage);
	void getRemoved();
    //virtual void getAttacked(Tower *attacker){}//只是让TOWER不报错
    void getAttacked(Tower1 *attacker);//
    void getAttacked(Tower2 *attacker);//
    //void gotLostSight(Tower *attacker){}//只是让TOWER不报错
    void gotLostSight(Tower1 *attacker);//具体执行时分别调自己的函数
    void gotLostSight(Tower2 *attacker);

	QPoint pos() const;
    int getEnemyType(){return enemyType;}
    void setEnemyType(){enemyType=2;}

public slots:
    void doActivate();//更改m_active状态
    //void getSlowDown();//新增函数//TOWER2的bullet会调用


private:
	bool			m_active;
	int				m_maxHp;
	int				m_currentHp;
	qreal			m_walkingSpeed;
	qreal			m_rotationSprite;

	QPoint			m_pos;
	WayPoint *		m_destinationWayPoint;
	MainWindow *	m_game;
    //QList<Tower *>	m_attackedTowersList;
    QList<Tower1 *>	m_attackedTowersList1;//
    QList<Tower2 *>	m_attackedTowersList2;//

	const QPixmap	m_sprite;
	static const QSize ms_fixedSize;
    int enemyType=1;//1为正常速度
};

#endif // ENEMY_H
