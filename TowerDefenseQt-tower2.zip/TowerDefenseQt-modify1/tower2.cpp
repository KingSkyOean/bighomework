#include "tower.h"
#include "enemy.h"
#include "bullet.h"
#include "mainwindow.h"
#include "utility.h"
#include <QPainter>
#include <QColor>
#include <QTimer>
#include <QVector2D>
#include <QtMath>
#include <QObject>
#include "tower2.h"

Tower2::Tower2(QPoint pos, MainWindow *game, const QPixmap &sprite /*= QPixmap(":/image/tower1.png")*/)
    : Tower(pos, game, sprite)
{
    m_attackRange=70;
    m_damage=10;
    m_fireRate=1000;
}

Tower2::~Tower2(){
    delete m_fireRateTimer;
    m_fireRateTimer = NULL;
}

void Tower2::shootWeapon(){
    Bullet *bullet = new Bullet(m_pos, m_chooseEnemy->pos(), m_damage, m_chooseEnemy, m_game);
    bullet->bulletmove();
    m_game->addBullet(bullet);
    m_chooseEnemy->setEnemyType();//
}
void Tower2::chooseEnemyForAttack(Enemy *enemy)
{
    m_chooseEnemy = enemy;
    attackEnemy();
    m_chooseEnemy->getAttacked(this);
}
void Tower2::lostSightOfEnemy()
{
    m_chooseEnemy->gotLostSight(this);
    if (m_chooseEnemy)
        m_chooseEnemy = NULL;

    m_fireRateTimer->stop();
    m_rotationSprite = 0.0;
}
